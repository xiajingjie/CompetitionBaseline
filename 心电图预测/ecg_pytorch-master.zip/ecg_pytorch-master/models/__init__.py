# -*- coding: utf-8 -*-
'''
@time: 2019/9/8 20:13

@ author: javis
'''

from .resnet import resnet34,resnet101